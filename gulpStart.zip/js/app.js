"use strict";

(function () {
  "use strict";

  console.log("Hello gulp");
})();